import sys

from engine import engine

mode = 'gpu'
dataset = '/media/aiembed/cf11bc1b-0f02-4383-ad36-da07690b0deb/ilsvrc/validation/'
mean_file = '/opt/caffe/ristretto/python/caffe/imagenet/ilsvrc_2012_mean.npy'
label_file = '/opt/caffe/ristretto/data/ilsvrc12/val.txt'
prefix = '/home/aiembed/date-iccd-paper/'
model_name = sys.argv[1]
quantized = 'q' # 'q' for quantized fixed-point or 'f' for floating-point representation
max_test_images = -1 # or a number < 50000 for the total number of tests

e = engine(dataset, mode, mean_file, label_file, model_name, quantized, prefix)

errors = [0, 1, 10, 50, 100, 1000, 5000, 10000]

output = open('output', 'w')

for n in errors:
  correct = e.perform_test(n, number_of_images=max_test_images)
  output.write('{} : {}\n'.format(n, correct))

e.reset(model_name, 'f')

for n in errors:
  correct = e.perform_test(n, number_of_images=max_test_images)
  output.write('{} : {}\n'.format(n, correct))
output.close()
