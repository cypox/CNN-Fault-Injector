import os

from model import classifier
from faults import injector


class engine:
  def __init__(self, dataset, mode, mean, label, name, quantized, prefix):
    self.dataset = dataset
    self.prefix = prefix
    print('loading labels')
    self.labels = dict()
    with open(label, 'r') as f:
      for line in f:
        line.replace('\n', '')
        if line != '':
          key = line.split(' ')[0]
          value = int(line.split(' ')[1])
          self.labels[key] = value

    model_file =   prefix + name + '/' + quantized + '_model.prototxt'
    weights_file = prefix + name + '/' + quantized + '_weights.caffemodel'
    self.net = classifier(model_file, weights_file, mean, mode)
    self.inj = injector(self.net, quantized)
  
  def reset(self, name, quantized):
    model_file =   self.prefix + name + '/' + quantized + '_model.prototxt'
    weights_file = self.prefix + name + '/' + quantized + '_weights.caffemodel'
    self.net.reset(model_file, weights_file)
    self.inj = injector(self.net, quantized)

  def perform_test(self, number_of_errors, number_of_images = -1):
    for i in range(number_of_errors):
      self.inj.inject_seu()

    total_predictions = 0.
    correct_predictions = 0.

    for filename in os.listdir(self.dataset):
      if total_predictions > number_of_images and number_of_images != -1:
        break
      if filename.endswith(".JPEG"):
        img_file = os.path.join(self.dataset, filename)
        out = self.net.predict(img_file)
        total_predictions += 1

        if self.labels[filename] == out['prob'].argmax():
          correct_predictions += 1
        
        print('correct predictions: {:.4f} progress: {:.4f}%\r'.format(correct_predictions/total_predictions, total_predictions/500.)), # it should be divied by 50k and multiplied by 100 for percent values

    return correct_predictions
